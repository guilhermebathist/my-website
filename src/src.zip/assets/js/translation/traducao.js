

function traducao() {

    $flagIdioma.src = 'https://www.flaticon.com/svg/static/icons/svg/197/197386.svg'

    //Menu Links
    $navAbout.innerHTML = `Sobre <i class="mdi mdi-chevron-down"></i>`;
    $navMe.innerHTML = "Mim";
    $navSkills.innerHTML = "Skills";
    $navServices.innerHTML = "Serviços";
    $navExperience.innerHTML = "Experiência";
    $navPortfolio.innerHTML = "Portfólio";
    $navContact.innerHTML = "Contato";

    //Modal Language
    $languageModalLabel.innerHTML = "Selecionar idioma";
    $infoTranslation.innerHTML = "A tradução para o idioma selecionado pode haver alguns erros. Eu já estou trabalhando nisso."

    // Header
    $headerTitle.innerHTML = "Eu sou Guilherme Bathist.";
    $headerDesc.innerHTML = "Meu Website ainda está em desenvolvimento, mas você já pode conferir um pouco do meu trabalho!";
    
}